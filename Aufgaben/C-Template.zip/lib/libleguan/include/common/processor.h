 /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
  *          _                                                      *
  *         | |                                                     *
  *         | |     ___  __ _ _   _  __ _ _ __                      *
  *         | |    / _ \/ _` | | | |/ _` | '_ \                     *
  *         | |___|  __/ (_| | |_| | (_| | | | |                    *
  *         \_____/\___|\__, |\__,_|\__,_|_| |_|                    *
  *        ============= __/ | ==================                   *
  *                     |___/           BFH 2021                    *
  *                                                                 *
  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
  * This software can be used by students and other personal of the *
  * Bern University of Applied Sciences under the terms of the MIT  *
  * license.                                                        *
  * For other persons this software is under the terms of the GNU   *
  * General Public License version 2.                               *
  *                                                                 *
  * Copyright &copy; 2021, Bern University of Applied Sciences.     *
  * All rights reserved.                                            *
  * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
/**
  *  @file processor.h
  *  @ingroup common
  *  @author Nikolaij Saegesser
  *  @brief Processor specific includes
  */

#pragma once

#if defined(__cplusplus)
extern "C" {
#endif


#if defined(LEGUAN_FIRMWARE_CPU)

	#include <stm32f7xx.h>
	#include <stm32f7xx_hal.h>
	#include <core_cm7.h>

#else

	#include <stm32h7xx.h>
	#include <stm32h7xx_hal.h>
	#include <core_cm7.h>

#endif


#if defined(__cplusplus)
}
#endif

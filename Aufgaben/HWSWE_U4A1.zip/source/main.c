/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U4A1
 *
 * This is code to test the cache of the microcontroller. It copies 1000 bytes
 * of data from one array to the other.
 * Each copy cycle is performed 1000 times, the system tick is set to 1ms.
 * Therefore, the result is the number of microseconds to copy one array.
 *
 * To copy the memory we use optimization level 0 that the compiler does not
 * optimize away the loop.
 * In main loop we use optimization level 3 due to problems in SCB_EnableDCache
 * if level would be 0. This is because some local variables in SCB_EnableDCache
 * are hold in cache and while disabling the cache, copied to memory, which
 * seems to be a problem. Using level 3, the local variables are stored in
 * registers.
 *
 * @version     1.0
 * @date        2022-01-27
 * @author      ssn1, WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-01-27 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>
#include <string.h>             /* for memcpy */
#include <stdio.h>              /* for snprintf */

/* define source and destination array to copy data */
#define BUFFER_SIZE 0x1000      /* the number of bytes copied */
static uint8_t src_data[BUFFER_SIZE];
static uint8_t dest_data[BUFFER_SIZE];

/* defines for Display */
#define LINE_LENGTH         (50)
/* positions to draw text */
#define POS_WELCOME         (20)
#define POS_WITHCACHE       (50)
#define POS_WITHLIB         (70)
/* text to display */
static const char *textWelcome = "Welcome to exercise U4A1";
static const char *textWithCache = "Time to copy 1000 Bytes with cache: %u us  ";
static const char *textWithoutCache = "Time to copy 1000 Bytes without cache: %u us";

/**
 * @brief       copyData
 *
 * Copies some data from a source to a destination and measures the time to do this.
 * The data is copied 1000 times to get a more accurate result.
 *
 * @param       dest    destination address
 * @param       source  source address
 * @param       size    number of bytes to copy
 *
 * @return      time in ms to copy the data 1000 times
 */
__attribute__((optimize("0")))  /* Make sure the compiler doesn't optimize away the loop */

uint32_t copyData(uint8_t *dest, uint8_t *source, uint32_t size)
{
    uint32_t start_tick;    /* tick count when starting copy process */
    uint32_t end_tick;      /* tick count when copy done */
    uint32_t copy_time;     /* time to copy 1000 times the array */
    uint32_t loop_time;     /* time to perform the loop */
    register uint32_t i;    /* loop variable */

    // measure time to copy the array
    //-------------------------------
    start_tick = HAL_GetTick();
    /* Loop 1000 times so the calculated tick count later on will directly correspond the
     * number of microseconds every loop iteration took.
     */
    for (i = 0; i < 1000; i++) {
        /* Copy all data from the source buffer to the destination buffer */
        memcpy(dest, source, size);
    }
    end_tick = HAL_GetTick();
    copy_time = end_tick - start_tick;

    /* measure time to do 1000 loops */
    start_tick = HAL_GetTick();
    for (i = 0; i < 1000; i++) {
        /* do nothing, just to get loop time */
    }
    end_tick = HAL_GetTick();
    loop_time = end_tick - start_tick;

    return (copy_time - loop_time);
}


/**
 * @brief       main function
 *
 * This main function initializes the Leguan board. It calls function
 * copyData() to do some memory access, once with cache enabled, once
 * with cache disabled.
 *
 * @param       none
 * @return      always 0
 */
__attribute__((optimize("3")))  /* Due to problems in SCB_DisableDCache() */

int main(void)
{
    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    /* Define colors for display and display welcome */
    LCD_SetForegroundColor(ColorWhite);
    LCD_SetBackgroundColor(ColorBlack);
    LCD_String(0,POS_WELCOME, textWelcome);

    /* Main loop */
    for (;;) {
        uint32_t ticks_used;            /* number of ticks the copy process uses */
        char text[LINE_LENGTH];         /* array to store text to display */

        /* copy data using cache and display result */
        SCB_EnableICache();
        SCB_EnableDCache();
        ticks_used = copyData(dest_data, src_data, BUFFER_SIZE);
        snprintf(text, LINE_LENGTH, textWithCache, (unsigned int)ticks_used);
        LCD_String(0, POS_WITHCACHE, text);

        /* copy data without cache and display result */
        SCB_DisableICache();
        SCB_DisableDCache();
        ticks_used = copyData(dest_data, src_data, BUFFER_SIZE);
        snprintf(text, LINE_LENGTH, textWithoutCache, (unsigned int)ticks_used);
        LCD_String(0, POS_WITHLIB, text);

        /* do some dealy (in ms) and start again */
        CORE_Delay(1000);
    }

    return (0);
}

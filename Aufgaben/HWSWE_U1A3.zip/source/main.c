/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U1A3
 *
 * This exercise uses the log functionality to send messages either to the LCD
 * or to the UART. Furthermore it does some calculations to show these variables
 * in the debugger.
 *
 * @version     1.0
 * @date        2022-01-28
 * @author      WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-01-28 created for BTE 5053 and Leguan
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>

/* define log output: if set, logoutput is LCD, otherwise UART */
/* default settings for UART are: 115.2k, 8 bit, no parity, 1 stop, no flowcontr. */
#define USE_LCD 1

/* text to log messages */
static const char *textWelcome = "Welcome to exercise U1A3";
static const char *textCalculation = "a = %u, b = %u, c = %u";
static const char *textLoopCounter = "Loop counter is: %u";


/**
 * @brief       main function
 *
 * This main function initializes the Leguan board. There is no additional
 * functionality in the main loop.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    uint32_t loop_count = 0;            /* counter, incremented each loop */
    uint32_t a = 0, b = 5, c;           /* variables to do some calculation */

    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be LCD or UART */
#ifdef USE_LCD
    LOG_SetDestination(LCD_Stream);
#else
    LOG_SetDestination(SERIAL_Stream);
#endif
    LOG_Info(textWelcome);

    /*  Main loop */
    for (;;) {

        /* log loop counter */
        LOG_Info(textLoopCounter, loop_count);
        loop_count++;                   /* increment counter each loop */

        /* calculate something very important, log actual values */
        a++;
        b = loop_count;
        c = a + b;
        /* set a breakpoint to view variables in debugger */
        LOG_Info(textCalculation, a, b, c);

        /* do some dealy (in ms) and start again */
        CORE_Delay(1000);
    }

    return (0);
}

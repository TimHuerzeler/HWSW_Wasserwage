/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U10A1
 *
 * This program defines some uninitialized and initialized variables.
 * Please check the map file and use the debugger to check the adresses and
 * the values of the variables.
 *
 * @version     1.0
 * @date        2022-05-03
 * @author      ssn1, WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-05-03 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>

/*----- Data types ---------------------------------------------------------*/
/* non-static initialized global variables */
/* goes to .data section */
int initialized_var = 0x11;

/* static initialized global variables */
/* remark: static variables are "hidden" and will not be visible in other source files */
static int static_initialized_var = 0x22;

/* non-static uninitialized global variables */
/* go to .bss section COMMON symbols */
int uninitialized_var;

/* static uninitialized global variables */
static int static_uninitialized_var;


/**
 * @brief       main function
 *
 * This main function initializes the Leguan board. There is no additional
 * functionality in the main loop.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    /* static local variables, hidden in other functions, visible in MAP-file */
    static int local_static_var = 0x55;

    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    /* write some values into uninitialized variables */
    uninitialized_var = 0x33;
    static_uninitialized_var = 0x44;

    /* Main loop */
    for (;;) {
        initialized_var++;
        static_initialized_var++;
        uninitialized_var++;
        static_uninitialized_var++;
        local_static_var++;
    }

    return (0);
}

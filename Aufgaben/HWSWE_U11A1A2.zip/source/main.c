/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise 11
 *
 * This program will turn on and of the decimal point of the 7-seg display.
 *
 * @version     1.0
 * @date        2022-05-10
 * @author      ssn1, WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-05-10 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>


/**
 * @brief       Init_GPIO_PB15_DP function
 *
 * This function initializes DP on GPIO PB 15.
 *
 * @param       none
 * @return      none
 */
void Init_GPIO_PB15_DP(void)
{
      /* GPIO port mode register, value 01 for GPIOB pin 15, general purpose output */
      GPIOB->MODER &= ~(1<<31);     // clear bit 31
      GPIOB->MODER |= (1<<30);      // set bit 30

      /* GPIO port output type register, type 0 (push-pull) */
      GPIOB->OTYPER &= ~(1<<15);    // clear bit 15 for push-pull pin 15

      /* GPIO port output speed register, value 11 for very high */
      GPIOB->OSPEEDR |= 0xC0000000; // set bit 30 and 31

      /* GPIO port pull-up/pull-down register, no pull-up/pull-down */
      GPIOB->PUPDR &= ~0xC0000000;  // clear bit 30 and 31

      /* turn output on to disable DP */
      GPIOB->BSRR = (1 << 15);      // set bit 15, clear decimal point
}

/**
 * @brief       main function
 *
 * This main function initializes GPIO Port B and turns on and off the decimal point.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    // Initialize decimal point on GPIO PB15
    Init_GPIO_PB15_DP();

    /* Main loop */
    for (;;) {
        // turn on and off GPIO B15 (decimal point seven-seg)
        // GPIO output low will turn the DP on
        // A1) use HAL Driver Library
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);
        HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);

        // A2) access HW-regs directly
        GPIOB->BSRR = (1 << 31);      // set bit 31 to clear outupt, set decimal point
        GPIOB->BSRR = (1 << 15);      // set bit 15 to set output, clear decimal point
    }

    return (0);
}

/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U13A1
 *
 * This code initializes Timer 2 low level to interrupt each second.
 * The decimal point of the seven segment display is toggled in the timer ISR.
 *
 * @version     1.0
 * @date        2022-05-25
 * @author      WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-05-25 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>

/**
  * @brief  This function handles Timer 2 interrupts.
  */
void TIM2_IRQHandler(void)
{
    /* Clear the IT peinding Bit */
    /* TIMx->SR, RM0433 p 1701, clear pin UIF (update interrupt flag) */
    TIM2->SR &= (uint16_t)~(0x01);
    /* toggle DP, which is port D pin 15 */
    GPIOB->ODR ^= (1 << 15);
}


/**
 * @brief       Init_GPIO_PB15_DP function
 *
 * This function initializes DP on GPIO PB 15.
 *
 * @param       none
 * @return      none
 */
void Init_GPIO_PB15_DP(void)
{
      /* GPIO port mode register, value 01 for GPIOB pin 15, general purpose output */
      GPIOB->MODER &= ~(1<<31);     // clear bit 31
      GPIOB->MODER |= (1<<30);      // set bit 30

      /* GPIO port output type register, type 0 (push-pull) */
      GPIOB->OTYPER &= ~(1<<15);    // clear bit 15 for push-pull pin 15

      /* GPIO port output speed register, value 11 for very high */
      GPIOB->OSPEEDR |= 0xC0000000; // set bit 30 and 31

      /* GPIO port pull-up/pull-down register, no pull-up/pull-down */
      GPIOB->PUPDR &= ~0xC0000000;  // clear bit 30 and 31

      /* turn output on to disable DP */
      GPIOB->BSRR = (1 << 15);      // set bit 15, clear decimal point
}

/**
 * @brief       Init_Timer2 function
 *
 * This function initializes timer 2.
 *
 * @param       none
 * @return      none
 */
void Init_Timer2(void)
{
    /* Enable Clock for Timer 2 */
    __HAL_RCC_TIM2_CLK_ENABLE();

    /* Configure Timer 2 for one second */

    /* TIM2 Control Reg1, RM0433 p 1694:
     * CKD (clock division) = 0;
     * DIR (direction count down) = 1;
     * all other bits 0
     */
    TIM2->CR1 = 0x0010;

    /* set the Autoreload value */
    TIM2->ARR = 10000; // interrupt each second

    /* set the prescaler value
     * clock for timer shall be 0.1ms,
     * peripheral clock is 120 MHz,
     * TIM2-CLK = 2*PCLK = 240 MHz,
     * therefore prescaler value is 24000 (240 MHz / 24000)
     */
    TIM2->PSC = 24000;

    /* TIM2 DMA / Interrupt Enable Register RM0433 p 1700
     * UIE = 1 (enable interrupt)
     */
    TIM2->DIER |= 0x01;

    /* TIM2 Control Reg1, RM0433 p 1694
     * CEN = 1 (counter enable)
     */
    TIM2->CR1 |= 0x01;

    /* enable TIM2 interrupt in NVIC, ISER (intrrupt set enable register,
     * vector number 28 */
    NVIC->ISER[0] = 1 << 28;
}

/**
 * @brief       main function
 *
 * This main function initializes the Leguan board. There is no additional
 * functionality in the main loop.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    /* init DP */
    Init_GPIO_PB15_DP();

    /* init timer 2 */
    Init_Timer2();

    __enable_irq();

    /* Main loop */
    for (;;) {

    }

    return (0);
}

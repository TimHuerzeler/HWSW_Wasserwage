/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U10A2
 *
 * This program demonstrates the interface for mixed projects, written in C
 * and assembler.
 *
 * @version     1.0
 * @date        2022-05-03
 * @author      ssn1, WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-05-03 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>

/* prototypes for assembler subroutines */
extern int asm_sub(int a, int b);
extern void asm_callcfunc(void);
extern void asm_modifyvar(void);

/*----- Data ---------------------------------------------------------------*/
int c_var = 0x33;               ///< example for a variable in C
extern int asm_var;             ///< example for a variable in assembler

/*----- Implementation -----------------------------------------------------*/
/**
 * @brief       C-function
 *
 * This C-function is called from assembler code. It adds both parameters and
 * returns the value of this addition.
 *
 * @param       two values to add
 * @return      sum of both parameters
 */
int cfunc(int par1, int par2){
    return(par1 + par2);
}


/**
 * @brief       main function
 *
 * This main function initializes the Leguan board. There is no additional
 * functionality in the main loop.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    /* local variables (auto) will be on stack */
    int a = 5;
    int b = 27;
    int res __attribute__((unused)); // suppress compiler warning using attribute

    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    /* Main loop */
    for (;;) {
        res = asm_sub(a, b);
        asm_callcfunc();
        asm_modifyvar();
        asm_var = 0x22;
        c_var = 0xAA;
    }

    return (0);
}

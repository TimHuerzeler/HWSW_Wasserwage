/**
 *****************************************************************************
 * @file        main.c
 * @brief       BTE 5053 HWSWE, Exercise U12A1
 *
 * This program uses a button on the Leguan board to generate an interrupt.
 * The button on the Leguan board is connected to GPIO port D pin 11.
 * The corresponding peripherals (GPIO, EXTI) and the NVIC are initialized.
 * The IRQ-Handler increment a counter eacht time the button is pressed.
 * The counter value will be displayed on the 7-seg display.
 *
 * @version     1.0
 * @date        2022-05-17
 * @author      ssn1, WBR1
 *
 * @remark      Last Modification
 *              \li wbr1 2022-05-17 created for BTE 5053
 *****************************************************************************
 */
#include <leguan.h>
#include <cube.h>

/* global button counter. This counter is incremented each time the
   button is pressed. The value is displayed on the 7-segment display */
static uint32_t btn_counter = 0;

/**
  * @brief  This function handles EXTI line[15:10] interrupts.
  *         The button is located at line 11.
  *         This handler will increment the button counter.
  */
void EXTI15_10_IRQHandler(void)
{
  /* Check if line 11 is active */
  if((EXTI->PR1 & (1 << 11)) != 0){
      /* clear pending bit */
      EXTI->PR1 = (1 << 11);
      /* increment global btn_counter*/
      btn_counter++;
  }
}


/**
 * @brief       Initializes all peripherals for the button interrupt.
 *
 * This function initializes the following peripherals:
 * GPIO PD11 for button (input)
 * Line Mappling for line 11
 * EXTI for line 11
 * NVIC for EXTI15_10_IRQHandler
 *
 * @param       none
 * @return      none
 */
void InitButtonInterrupt(void)
{
    /* The button is connected to PD11 */
    /* Set button GPIO to be an input pin with no pullup */
    /* GPIO port mode register, value 00 for GPIOD pin 11, general purpose output */
    GPIOD->MODER &= ~((1<<23) | (1<<22));     // clear bit 22 and 23
    /* GPIO port pull-up/pull-down register, no pull-up/pull-down */
    GPIOD->PUPDR &= ~((1<<23) | (1<<22));  // clear bit 22 and 23

    /* External Line Mapping / SYSCFG */
    /* Multiplexer for EXTI line 11 is set to GPIOD */
    /* EXTICR3 is EXTICR[2] */
    SYSCFG->EXTICR[2] &= ~(0xF000);   // clear all pins (12 to 15) for EXTI11
    SYSCFG->EXTICR[2] |= 0x3000;    // set pins to 0011 (bit 12 and 13) for line mapping to port D
    /* another way to program EXTICR using #defines in stm32h743xx.h:
    SYSCFG->EXTICR[2] &= ~(SYSCFG_EXTICR3_EXTI11_Msk);
    SYSCFG->EXTICR[2] |= SYSCFG_EXTICR3_EXTI11_PD; */

    /* EXTI Controller, define line 11 for rising edge and interrupt */
    /* Set Interrupt mask register for EXTI_Line11 to enable interrupt */
    EXTI->IMR1 |= EXTI_IMR1_IM11;
    /* Rising edge configuration, trigger enabled for line 11 */
    EXTI->RTSR1 |= EXTI_RTSR1_TR11;
    /* Falling edge configuration, trigger disabled for line 11 */
    EXTI->FTSR1 &= ~EXTI_FTSR1_TR11;

    /* Configure NVIC to enable EXTI line 11 interrupt */
    /* Line 11 is handled in EXTI15_10_IRQn */
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
}

/**
 * @brief       main function
 *
 * This main function initializes the Leguan board, the GPIO and the button-interrupt.
 *
 * @param       none
 * @return      always 0
 */
int main(void)
{
    /* Initialize Hardware */
    CUBEMX_Init();
    /* Initialize Leguan board */
    LEGUAN_Init();

    /* Set logging output destination to be the LCD */
    LOG_SetDestination(LCD_Stream);

    /* initialize all peripherals for button interrupt */
    InitButtonInterrupt();

    __enable_irq();

    /* Main loop */
    for (;;) {
        FPGA_7SegDisplayDecimal(btn_counter);
    }
}
